// NOTE: bug代码 不要动
// BUG: 有问题的代码
/*this.create_btn=function (text,id)
  {
    var btn=$("<button></button")
    btn.getId=function()
    {
      return btn.attr("id")
    }
    btn.setId=function()
    {
      btn.attr("id",id)
    }
   //var btn=$("<button"+" "+"id="+id>"+"</button>").text(text)
   btn.attr("id",id)
   btn.text(text)
   console.warn(btn);
   // NOTE: 默认内置button样式设置
   btn.css("background","orange")
   btn.css("border","solid")
   btn.css("width","100px")
   btn.css("height","50px")

   //调试
   console.warn('以下id从引擎打印');
   console.log('id->'+btn.attr("id"));
   return btn
}*/
