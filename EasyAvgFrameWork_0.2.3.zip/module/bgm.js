// NOTE: 播放音乐js
$(function()
{
  $("#start").click(function()
  {
    var b=$("#bgm")
    console.log(b)
    b[0].play()
  })

})
