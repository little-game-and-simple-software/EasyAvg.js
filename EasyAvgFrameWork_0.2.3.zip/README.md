这时一个基于jquery html5 js 没有用canvas视觉小说开源库
<br>开发中 做这个也是练习一下技术 

<br><h1>此开源库特点：轻量级</h1>
运行例子

<img src="example.png" alt="例子">
<img src="https://s3.ax1x.com/2021/01/29/yiA4pt.png" alt="图床">

1. core.js是它的核心 只有7kb大小
2. 每个功能分模块使用 你可以在module文件夹下面看见不同的模块
3. 灵活性大，每个对象基本都是jquery对象，你可以根据自己的需求自由更改代码，添加代码
4. 运行在浏览器上，跨平台，当然你也可以使用其他工具打包
5. var Engine=new EasyAvg() 使用此方法获得引擎类

<a target="_blank" href="https://github.com/little-game-and-simple-software/EasyAvgFrameWork/releases/download/0.01_demo/EasyAvgFrameWork.zip" >Demo下载</a>

<h2>API</h2>
1. API可以在API.txt.js查看
2. 你可以通过源码学习如何使用此开源库

<br>
<h2>许可协议：</h2>
1. 
对于开源游戏和免费游戏是免费使用的。对于商业游戏需要联系我，取得许可
<br>如果复制了此开源库并进行了修改，必须保留此文件。
此开源库中的素材，请勿用于商业用途，仅供学习与研究

<br>欢迎各位提交issue pull request

Demo中使用的素材来源于noesis视觉小说<br>
<h2>CopyRight© 小沙盒工作室</h2>