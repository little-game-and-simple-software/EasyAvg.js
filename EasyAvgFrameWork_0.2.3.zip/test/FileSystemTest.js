/*// NOTE: 初始化
var fileSystem=new FileSystem()
console.log("##自动化测试开始##")
console.log("存档和读档正确代码测试")
fileSystem.save("hello","hello")
var data=fileSystem.load("hello")
console.log(data)
console.log("##错误代码测试##")
fileSystem.save("hello","hello")
var data=fileSystem.load("hello")
console.log(data)
*/
